(() => {
  const state = { entered: 0, stored: 0, running: false, transfers: 0, clock: 0 };
  const $ = (id) => document.getElementById(id);
  const bits = (n) => n.toString(2).padStart(2, '0');
  const setText = (id, value) => { const el = $(id); if (el) el.textContent = value; };
  const toggle = (target, bit) => {
    if (state.running) return;
    const mask = 1 << Number(bit);
    state[target] = (state[target] & mask) ? (state[target] & ~mask) : (state[target] | mask);
    updateInputs();
  };
  function updateInputs() {
    ['entered','stored'].forEach(target => {
      const value = state[target];
      setText(target === 'entered' ? 'enteredValue' : 'storedValue', bits(value));
      [1,0].forEach(bit => {
        setText(`${target}Bit${bit}`, (value >> bit) & 1);
        const button = document.querySelector(`.bit-switch[data-target="${target}"][data-bit="${bit}"]`);
        if (button) button.setAttribute('aria-pressed', ((value >> bit) & 1) ? 'true' : 'false');
      });
    });
    setText('pipeMasterBits', bits(state.entered));
    setText('pipeSlaveBits', '— —');
  }
  function setPhase(text) { setText('phaseText', text); }
  function setNode(id, cls) { const el = $(id); if (el) el.className = `pipe-node${cls ? ' ' + cls : ''}`; }
  function clearPipes() {
    ['nodeMaster','nodeSlave','nodeStatus','nodeReceiver'].forEach(id => setNode(id,''));
    ['wireForward','wireReturn'].forEach(id => { const el=$(id); if(el) el.classList.remove('animating'); });
  }
  const wait = (ms) => new Promise(resolve => setTimeout(resolve, ms));
  async function runTransfer() {
    if (state.running) return;
    state.running = true;
    document.querySelectorAll('.bit-switch').forEach(b => b.disabled = true);
    $('runTransfer').disabled = true;
    clearPipes();
    const match = state.entered === state.stored;
    const mismatch = !match;
    const statusBits = match ? '10' : '01';
    setText('clockCount', '00'); setText('transferStatus', 'Transfer in progress…');
    setText('resultTitle','Transferring data…'); setText('resultDesc','Loading the parallel input, shifting two bits, and comparing the values.');
    setText('resultIcon','◌'); $('resultIcon').className = 'result-icon';
    $('greenLed').classList.remove('on'); $('redLed').classList.remove('on');
    setText('pipeMasterBits', bits(state.entered)); setText('pipeSlaveBits','00'); setText('pipeStatusBits','— —'); setText('pipeReturnBits','— —');
    setPhase('PHASE 01 / LOAD'); setNode('nodeMaster','active'); await wait(420);
    setPhase('PHASE 02 / SHIFT'); $('wireForward').classList.add('animating');
    for (let i=1;i<=2;i++) { setText('clockCount',String(i).padStart(2,'0')); await wait(360); }
    $('wireForward').classList.remove('animating'); setNode('nodeMaster','done'); setNode('nodeSlave','active'); setText('pipeSlaveBits',bits(state.entered));
    setPhase('PHASE 03 / COMPARE'); await wait(520);
    setNode('nodeSlave','done'); setNode('nodeStatus','active'); setText('pipeStatusBits',statusBits);
    setPhase('PHASE 04 / RETURN'); $('wireReturn').classList.add('animating');
    for (let i=3;i<=4;i++) { setText('clockCount',String(i).padStart(2,'0')); await wait(360); }
    $('wireReturn').classList.remove('animating'); setNode('nodeStatus','done'); setNode('nodeReceiver','active'); setText('pipeReturnBits',statusBits); await wait(400); setNode('nodeReceiver','done');
    setPhase('COMPLETE / LATCHED');
    $('greenLed').classList.toggle('on', match); $('redLed').classList.toggle('on', mismatch);
    $('resultIcon').textContent = match ? '✓' : '×'; $('resultIcon').className = `result-icon ${match ? 'granted' : 'denied'}`;
    setText('resultTitle', match ? 'ACCESS GRANTED' : 'ACCESS DENIED');
    setText('resultDesc', match ? `Entered ${bits(state.entered)} matches stored ${bits(state.stored)}. Correct status returned to the master.` : `Entered ${bits(state.entered)} does not match stored ${bits(state.stored)}. Mismatch status returned to the master.`);
    state.transfers++; setText('transferStatus',`Transfer #${state.transfers} complete · ${match ? 'MATCH' : 'MISMATCH'}`);
    state.running = false; document.querySelectorAll('.bit-switch').forEach(b => b.disabled = false); $('runTransfer').disabled = false;
  }
  function reset() {
    if (state.running) return;
    state.entered=0; state.stored=0; state.clock=0; clearPipes(); updateInputs();
    setText('clockCount','00'); setPhase('READY / IDLE'); setText('pipeSlaveBits','00'); setText('pipeStatusBits','— —'); setText('pipeReturnBits','— —');
    setText('resultTitle','Waiting for transfer'); setText('resultDesc','Choose two values and execute the transfer to see the result.'); setText('resultIcon','◌'); $('resultIcon').className='result-icon';
    $('greenLed').classList.remove('on'); $('redLed').classList.remove('on'); setText('transferStatus', state.transfers ? `${state.transfers} transfer(s) completed this session` : 'No transfer executed yet');
  }
  document.querySelectorAll('.bit-switch').forEach(button => button.addEventListener('click', () => toggle(button.dataset.target, button.dataset.bit)));
  $('runTransfer').addEventListener('click', runTransfer); $('resetSim').addEventListener('click', reset);
  $('menuToggle').addEventListener('click', () => $('navLinks').classList.toggle('open'));
  document.querySelectorAll('#navLinks a').forEach(a => a.addEventListener('click', () => $('navLinks').classList.remove('open')));
  const sections = [...document.querySelectorAll('main section[id]')];
  const navAnchors = [...document.querySelectorAll('#navLinks a')];
  if ('IntersectionObserver' in window) {
    const observer = new IntersectionObserver(entries => entries.forEach(entry => { if(entry.isIntersecting){navAnchors.forEach(a=>a.classList.toggle('active',a.getAttribute('href')==='#'+entry.target.id));} }), {rootMargin:'-30% 0px -60% 0px'});
    sections.forEach(section=>observer.observe(section));
  }
  updateInputs();
})();
